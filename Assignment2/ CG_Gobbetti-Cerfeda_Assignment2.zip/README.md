# Assignment 2

## Authors
- Alessandro Gobbetti
- Albert Cerfeda

## Solved exercises
- Exercise 1
- Exercise 2
- Exercise 3
- Exercise 4
