# Assignment 3
<image src="./render/result.png" width="60%">

## Authors
- Alessandro Gobbetti
- Albert Cerfeda

## Solved exercises
- Exercise 1
- Exercise 2
  - checkerboardTexture
  - rainbowCheckerboard
- Exercise 3
