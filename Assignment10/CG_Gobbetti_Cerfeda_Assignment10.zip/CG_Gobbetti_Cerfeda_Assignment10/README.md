# Assignment 10 - Texturing
<image src="./render/result.gif" width="60%">

## Authors
- Alessandro Gobbetti
- Albert Cerfeda

## Solved exercises
- Texturing the Raytracer [18 points]
