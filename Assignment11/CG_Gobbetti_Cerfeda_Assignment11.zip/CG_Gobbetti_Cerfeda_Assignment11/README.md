# Assignment 11 - Mass-spring System
<image src="./render/result.gif" width="60%">

## Authors
- Alessandro Gobbetti
- Albert Cerfeda

## Solved exercises
- Exercise 1 [9 points]
- Exercise 2 [3 points]
- Exercise 3 [3 points]
